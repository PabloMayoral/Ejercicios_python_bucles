#!/usr/bin/python3

from pwn import *
from Crypto.PublicKey import RSA
from Crypto.Util.number import *
import gmpy2

f = open("wh1tedrvg0n.pem", "r")

key = RSA.importKey(f.read())

e = key.e
n = key.n

log.info("e: %s" % e)
log.info("n: %s" % n)

for k in range(1,10000000):
    if gmpy2.iroot(1+4*e*k*n, 2)[1] == True:
        q = (int(1+gmpy2.iroot(1+4*e*k*n, 2)[0]))//(2*e)

        if n % q == 0:
            break

log.info("q: %s" % q)

p = n//q

m = n-(p+q-1)

def egcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(b % a, a)
        return (g, x - (b // a) * y, y)

def modinv(a, m):
    g, x, y = egcd(a, m)
    if g != 1:
        raise Exception('modular inverse does not exist')
    else:
        return x % m

log.info("p: %s" % p)

d = modinv(e, m)

key = RSA.construct((n, e, d, p, q))

print("\n", key.exportKey().decode())